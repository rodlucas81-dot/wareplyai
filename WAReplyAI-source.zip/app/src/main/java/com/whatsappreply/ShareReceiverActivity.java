package com.whatsappreply;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShareReceiverActivity extends Activity {

    private static final String API_KEY = "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";
    private static final String MODEL = "claude-sonnet-4-5";

    private String chatText = "";
    private String yourName = "";
    private List<String> senders = new ArrayList<>();

    // Conversation history for refinements
    private List<JSONObject> conversationHistory = new ArrayList<>();
    private String lastRepliesJson = "";

    // State for personal-question flow
    private JSONArray pendingGroups = null;
    private int currentPersonalIdx = -1;
    private List<String> personalAnswers = new ArrayList<>();

    private LinearLayout nameSelectorLayout;
    private LinearLayout nameButtonsContainer;
    private LinearLayout contextInputLayout;
    private LinearLayout loadingLayout;
    private LinearLayout resultsContainer;
    private LinearLayout personalQuestionLayout;
    private LinearLayout refinementLayout;
    private LinearLayout chipContainer;
    private EditText contextInput;
    private EditText personalAnswerInput;
    private EditText refinementInput;
    private TextView errorText;
    private TextView contactName;
    private TextView personalQuestionText;
    private Button generateBtn;
    private Button submitAnswerBtn;
    private Button refinementBtn;

    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private static final String[] QUICK_CHIPS = {
        "Make it shorter", "Make it longer", "Less formal", "More formal",
        "Add a joke", "Be more direct", "Softer tone", "More enthusiastic"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);

        nameSelectorLayout = findViewById(R.id.nameSelectorLayout);
        nameButtonsContainer = findViewById(R.id.nameButtonsContainer);
        contextInputLayout = findViewById(R.id.contextInputLayout);
        loadingLayout = findViewById(R.id.loadingLayout);
        resultsContainer = findViewById(R.id.resultsContainer);
        personalQuestionLayout = findViewById(R.id.personalQuestionLayout);
        refinementLayout = findViewById(R.id.refinementLayout);
        chipContainer = findViewById(R.id.chipContainer);
        contextInput = findViewById(R.id.contextInput);
        personalAnswerInput = findViewById(R.id.personalAnswerInput);
        refinementInput = findViewById(R.id.refinementInput);
        errorText = findViewById(R.id.errorText);
        contactName = findViewById(R.id.contactName);
        personalQuestionText = findViewById(R.id.personalQuestionText);
        generateBtn = findViewById(R.id.generateBtn);
        submitAnswerBtn = findViewById(R.id.submitAnswerBtn);
        refinementBtn = findViewById(R.id.refinementBtn);

        generateBtn.setOnClickListener(v -> fetchSuggestions());
        submitAnswerBtn.setOnClickListener(v -> submitPersonalAnswer());
        refinementBtn.setOnClickListener(v -> submitRefinement());

        refinementInput.setOnEditorActionListener((v, actionId, event) -> {
            submitRefinement(); return true;
        });

        // Build quick chips
        for (String chip : QUICK_CHIPS) {
            Button b = new Button(this);
            b.setText(chip);
            b.setTextSize(12f);
            b.setTextColor(Color.parseColor("#25D366"));
            b.setBackground(getDrawable(R.drawable.chip_selector));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.setMarginEnd(8);
            b.setLayoutParams(p);
            b.setPadding(24, 12, 24, 12);
            b.setOnClickListener(v -> {
                refinementInput.setText(chip);
                submitRefinement();
            });
            chipContainer.addView(b);
        }

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (sharedText != null) { chatText = sharedText; processChat(); return; }
            }
            Uri fileUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (fileUri != null) { readFileUri(fileUri); return; }
        }
        showError("No chat data received. Please share a WhatsApp chat export.");
    }

    private void readFileUri(Uri uri) {
        executor.execute(() -> {
            try {
                InputStream peek = getContentResolver().openInputStream(uri);
                byte[] magic = new byte[4]; peek.read(magic, 0, 4); peek.close();
                boolean isZip = (magic[0] == 0x50 && magic[1] == 0x4B);
                InputStream is = getContentResolver().openInputStream(uri);
                chatText = isZip ? readFromZip(is) : readText(is);
                mainHandler.post(this::processChat);
            } catch (Exception e) {
                mainHandler.post(() -> showError("Could not read file: " + e.getMessage()));
            }
        });
    }

    private String readFromZip(InputStream is) throws Exception {
        java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(is);
        java.util.zip.ZipEntry entry;
        while ((entry = zis.getNextEntry()) != null)
            if (entry.getName().toLowerCase().endsWith(".txt")) return readText(zis);
        throw new Exception("No .txt file found inside the zip.");
    }

    private String readText(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line).append("\n");
        reader.close();
        return sb.toString();
    }

    private void processChat() {
        if (chatText == null || chatText.trim().isEmpty()) { showError("Chat appears to be empty."); return; }
        senders = parseSenders(chatText);
        nameSelectorLayout.setVisibility(View.VISIBLE);
        nameButtonsContainer.removeAllViews();

        for (String sender : senders) {
            Button chip = new Button(this);
            chip.setText(sender);
            chip.setTextColor(Color.parseColor("#bbbbbb"));
            chip.setTextSize(13f);
            chip.setBackground(getDrawable(R.drawable.chip_selector));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMarginEnd(8);
            chip.setLayoutParams(params);
            chip.setPadding(32, 16, 32, 16);
            chip.setOnClickListener(v -> {
                yourName = sender;
                for (int i = 0; i < nameButtonsContainer.getChildCount(); i++) {
                    View child = nameButtonsContainer.getChildAt(i);
                    child.setSelected(false);
                    ((Button) child).setTextColor(Color.parseColor("#bbbbbb"));
                }
                chip.setSelected(true);
                chip.setTextColor(Color.parseColor("#25D366"));
                contextInputLayout.setVisibility(View.VISIBLE);
            });
            nameButtonsContainer.addView(chip);
        }

        if (!senders.isEmpty()) {
            yourName = senders.get(senders.size() - 1);
            View lastChip = nameButtonsContainer.getChildAt(senders.size() - 1);
            if (lastChip != null) { lastChip.setSelected(true); ((Button) lastChip).setTextColor(Color.parseColor("#25D366")); }
            contextInputLayout.setVisibility(View.VISIBLE);
        } else {
            contextInputLayout.setVisibility(View.VISIBLE);
        }
    }

    private List<String> parseSenders(String text) {
        LinkedHashSet<String> found = new LinkedHashSet<>();
        String[] patterns = {
            "^\\[\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?\\]\\s+(.+?):",
            "^\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?\\s+-\\s+(.+?):",
            "^\\[\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?\\]\\s+(.+?):",
        };
        for (String pat : patterns) {
            Pattern p = Pattern.compile(pat, Pattern.MULTILINE);
            Matcher m = p.matcher(text);
            while (m.find()) {
                String name = m.group(1).trim();
                if (!name.isEmpty() && !name.equals("You") && name.length() < 40) found.add(name);
            }
            if (!found.isEmpty()) break;
        }
        return new ArrayList<>(found);
    }

    private List<String[]> findUnansweredMessages() {
        String[] patterns = {
            "^(\\[\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?\\])\\s+(.+?):\\s(.+)$",
            "^(\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?\\s+-\\s+)(.+?):\\s(.+)$",
        };
        Pattern usedPattern = null;
        for (String pat : patterns) {
            Pattern p = Pattern.compile(pat, Pattern.MULTILINE);
            if (p.matcher(chatText).find()) { usedPattern = p; break; }
        }
        if (usedPattern == null) return new ArrayList<>();

        List<String[]> messages = new ArrayList<>();
        StringBuilder currentText = new StringBuilder();
        String currentSender = null;
        for (String line : chatText.split("\n")) {
            Matcher m = usedPattern.matcher(line);
            if (m.find()) {
                if (currentSender != null) messages.add(new String[]{currentSender, currentText.toString().trim()});
                currentSender = m.group(2).trim();
                currentText = new StringBuilder(m.group(3));
            } else if (currentSender != null && !line.trim().isEmpty()) {
                currentText.append(" ").append(line.trim());
            }
        }
        if (currentSender != null) messages.add(new String[]{currentSender, currentText.toString().trim()});

        int lastMyIdx = -1;
        for (int i = messages.size() - 1; i >= 0; i--)
            if (messages.get(i)[0].equals(yourName)) { lastMyIdx = i; break; }

        List<String[]> unanswered = new ArrayList<>();
        for (int i = lastMyIdx + 1; i < messages.size(); i++) {
            String[] msg = messages.get(i);
            if (!msg[0].equals(yourName) && !msg[1].isEmpty()) unanswered.add(msg);
        }
        if (unanswered.size() > 5) unanswered = unanswered.subList(unanswered.size() - 5, unanswered.size());
        return unanswered;
    }

    private void fetchSuggestions() {
        conversationHistory.clear();
        loadingLayout.setVisibility(View.VISIBLE);
        resultsContainer.removeAllViews();
        errorText.setVisibility(View.GONE);
        refinementLayout.setVisibility(View.GONE);
        personalQuestionLayout.setVisibility(View.GONE);
        pendingGroups = null;
        personalAnswers.clear();

        List<String[]> unanswered = findUnansweredMessages();
        String extraContext = contextInput.getText().toString().trim();

        String[] lines = chatText.split("\n");
        int start = Math.max(0, lines.length - 100);
        StringBuilder trimmed = new StringBuilder();
        for (int i = start; i < lines.length; i++) trimmed.append(lines[i]).append("\n");

        final String chatCtx = trimmed.toString();
        final List<String[]> finalUnanswered = unanswered;

        executor.execute(() -> {
            try {
                String result = callClaudeAPI(chatCtx, finalUnanswered, extraContext, null);
                mainHandler.post(() -> handleAPIResult(result, finalUnanswered));
            } catch (Exception e) {
                mainHandler.post(() -> { loadingLayout.setVisibility(View.GONE); showError("Error: " + e.getMessage()); });
            }
        });
    }

    private void handleAPIResult(String jsonStr, List<String[]> unanswered) {
        loadingLayout.setVisibility(View.GONE);
        try {
            JSONObject data = new JSONObject(jsonStr);
            if (data.optBoolean("needsPersonalInfo", false)) {
                pendingGroups = new JSONArray();
                pendingGroups.put(data);
                personalAnswers = new ArrayList<>();
                personalAnswers.add("");
                currentPersonalIdx = 0;
                String question = data.optString("personalQuestion", "Can you share more details?");
                String context = data.optString("personalMessageContext", "");
                personalQuestionLayout.setVisibility(View.VISIBLE);
                personalAnswerInput.setText("");
                personalAnswerInput.requestFocus();
                personalQuestionText.setText((context.isEmpty() ? "" : "Re: \"" + context + "\"\n\n") + question);
            } else {
                displayResults(data);
            }
        } catch (Exception e) {
            showError("Could not parse: " + e.getMessage() + "\n\n" + jsonStr);
        }
    }

    private void submitPersonalAnswer() {
        String answer = personalAnswerInput.getText().toString().trim();
        if (answer.isEmpty()) { Toast.makeText(this, "Please enter an answer", Toast.LENGTH_SHORT).show(); return; }
        personalAnswers.set(0, answer);
        personalQuestionLayout.setVisibility(View.GONE);
        fetchWithPersonalAnswers();
    }

    private void fetchWithPersonalAnswers() {
        loadingLayout.setVisibility(View.VISIBLE);
        resultsContainer.removeAllViews();
        List<String[]> unanswered = findUnansweredMessages();
        String extraContext = contextInput.getText().toString().trim();
        String[] lines = chatText.split("\n");
        int start = Math.max(0, lines.length - 100);
        StringBuilder trimmed = new StringBuilder();
        for (int i = start; i < lines.length; i++) trimmed.append(lines[i]).append("\n");
        String answers = "My answer: " + personalAnswers.get(0);
        final String chatCtx = trimmed.toString();
        final List<String[]> finalUnanswered = unanswered;
        final String finalAnswers = answers;
        executor.execute(() -> {
            try {
                String result = callClaudeAPI(chatCtx, finalUnanswered, extraContext, finalAnswers);
                mainHandler.post(() -> {
                    loadingLayout.setVisibility(View.GONE);
                    try { displayResults(new JSONObject(result)); }
                    catch (Exception e) { showError("Parse error: " + e.getMessage()); }
                });
            } catch (Exception e) {
                mainHandler.post(() -> { loadingLayout.setVisibility(View.GONE); showError("Error: " + e.getMessage()); });
            }
        });
    }

    private String callClaudeAPI(String chatContext, List<String[]> unanswered, String extraContext, String personalAnswers) throws Exception {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Here is a WhatsApp conversation:\n\n").append(chatContext).append("\n\n");
        prompt.append("I am \"").append(yourName).append("\" and need to reply.\n");
        if (!extraContext.isEmpty()) prompt.append("Additional context: ").append(extraContext).append("\n");
        if (personalAnswers != null && !personalAnswers.isEmpty())
            prompt.append("\nPersonal info I provided:\n").append(personalAnswers).append("\n");

        if (unanswered.isEmpty()) {
            prompt.append("\nAnalyze the last message and reply to it.\n");
        } else {
            prompt.append("\nThere are ").append(unanswered.size()).append(" unanswered message(s) I need to reply to:\n");
            for (int i = 0; i < unanswered.size(); i++)
                prompt.append((i+1)).append(". ").append(unanswered.get(i)[0]).append(": ").append(unanswered.get(i)[1]).append("\n");
        }

        prompt.append("\nFirst, check if any message requires personal info only I would know ");
        prompt.append("(e.g. what I ate, where I want to go, my personal plans, opinions on things only I know).\n\n");

        if (personalAnswers == null) {
            prompt.append("If ANY message needs personal info: set needsPersonalInfo=true and ask one SHORT question. Leave replies empty.\n");
            prompt.append("If NO messages need personal info: set needsPersonalInfo=false and generate ONE consolidated reply covering ALL messages together.\n\n");
        } else {
            prompt.append("Using the personal info I provided, generate ONE consolidated reply covering ALL messages.\n\n");
        }

        prompt.append("The reply must read like ONE natural WhatsApp message — not bullet points, not separate paragraphs per topic. ");
        prompt.append("Flow naturally from topic to topic the way a real person would text.\n");
        prompt.append("Detect the conversation language and reply in the SAME language.\n\n");
        prompt.append("Respond ONLY with JSON (no markdown, no preamble):\n");
        prompt.append("{\n");
        prompt.append("  \"summary\": \"one sentence about the conversation\",\n");
        prompt.append("  \"needsPersonalInfo\": false,\n");
        prompt.append("  \"personalQuestion\": \"(only if needsPersonalInfo=true) short question for me\",\n");
        prompt.append("  \"personalMessageContext\": \"(only if needsPersonalInfo=true) which message needs info\",\n");
        prompt.append("  \"replies\": [\n");
        prompt.append("    {\"style\": \"Friendly\", \"emoji\": \"💬\", \"text\": \"one natural message covering everything\"},\n");
        prompt.append("    {\"style\": \"Thoughtful\", \"emoji\": \"✍️\", \"text\": \"one natural message covering everything\"},\n");
        prompt.append("    {\"style\": \"Snappy\", \"emoji\": \"⚡\", \"text\": \"one natural message covering everything\"}\n");
        prompt.append("  ]\n");
        prompt.append("}");

        JSONObject requestBody = new JSONObject();
        requestBody.put("model", MODEL);
        requestBody.put("max_tokens", 2000);
        requestBody.put("system", "You are a WhatsApp reply assistant. Always respond ONLY with valid JSON. No preamble, no markdown fences.");
        JSONArray messages = new JSONArray();
        JSONObject userMsg = new JSONObject();
        userMsg.put("role", "user");
        userMsg.put("content", prompt.toString());
        messages.put(userMsg);
        requestBody.put("messages", messages);

        // Store in history for refinements
        conversationHistory.add(userMsg);

        URL url = new URL("https://api.anthropic.com/v1/messages");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", API_KEY);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        OutputStream os = conn.getOutputStream();
        os.write(requestBody.toString().getBytes("UTF-8"));
        os.close();

        int responseCode = conn.getResponseCode();
        InputStream is = responseCode == 200 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();

        if (responseCode != 200) throw new Exception("API error " + responseCode + ": " + response.toString());
        JSONObject resp = new JSONObject(response.toString());
        String text = resp.getJSONArray("content").getJSONObject(0).getString("text");
        return text.replaceAll("```json", "").replaceAll("```", "").trim();
    }

    private void displayResults(JSONObject data) throws Exception {
        resultsContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        // Summary card
        String summary = data.optString("summary", "");
        if (!summary.isEmpty()) {
            View summaryCard = inflater.inflate(R.layout.item_reply, resultsContainer, false);
            ((TextView) summaryCard.findViewById(R.id.replyLabel)).setText("CONVERSATION SUMMARY");
            ((TextView) summaryCard.findViewById(R.id.replyText)).setText(summary);
            summaryCard.findViewById(R.id.copyBtn).setVisibility(View.GONE);
            resultsContainer.addView(summaryCard);
        }

        // Three reply options as flat cards
        JSONArray replies = data.optJSONArray("replies");
        if (replies != null) {
            for (int r = 0; r < replies.length(); r++) {
                JSONObject reply = replies.getJSONObject(r);
                String style = reply.optString("style", "Reply");
                String emoji = reply.optString("emoji", "💬");
                String text = reply.optString("text", "");

                View card = inflater.inflate(R.layout.item_reply, resultsContainer, false);
                ((TextView) card.findViewById(R.id.replyLabel)).setText(emoji + " " + style.toUpperCase());
                ((TextView) card.findViewById(R.id.replyText)).setText(text);

                Button copyBtn = card.findViewById(R.id.copyBtn);
                final String finalText = text;
                copyBtn.setOnClickListener(v -> {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("reply", finalText));
                    copyBtn.setText("Copied!");
                    copyBtn.setTextColor(Color.parseColor("#25D366"));
                    mainHandler.postDelayed(() -> {
                        copyBtn.setText("Copy");
                        copyBtn.setTextColor(Color.parseColor("#aaaaaa"));
                    }, 2000);
                    Toast.makeText(this, "Copied! Switch to WhatsApp to paste.", Toast.LENGTH_SHORT).show();
                });
                resultsContainer.addView(card);
            }
        }
        refinementLayout.setVisibility(View.VISIBLE);
        refinementInput.setText("");

        // Store assistant reply in history for follow-ups
        try {
            JSONObject assistantMsg = new JSONObject();
            assistantMsg.put("role", "assistant");
            assistantMsg.put("content", data.toString());
            conversationHistory.add(assistantMsg);
        } catch (Exception ignored) {}
    }

    private void submitRefinement() {
        String request = refinementInput.getText().toString().trim();
        if (request.isEmpty()) return;

        loadingLayout.setVisibility(View.VISIBLE);
        resultsContainer.removeAllViews();
        refinementLayout.setVisibility(View.GONE);
        refinementInput.setText("");

        // Add user refinement request to history
        try {
            JSONObject userMsg = new JSONObject();
            userMsg.put("role", "user");
            userMsg.put("content", "Please revise the reply suggestions: " + request + "\n\nKeep the same JSON format. Respond ONLY with valid JSON.");
            conversationHistory.add(userMsg);
        } catch (Exception ignored) {}

        final List<JSONObject> history = new ArrayList<>(conversationHistory);

        executor.execute(() -> {
            try {
                String result = callClaudeAPIWithHistory(history);
                mainHandler.post(() -> {
                    loadingLayout.setVisibility(View.GONE);
                    try {
                        JSONObject data = new JSONObject(result.replaceAll("```json", "").replaceAll("```", "").trim());
                        displayResults(data);
                    } catch (Exception e) {
                        showError("Parse error: " + e.getMessage());
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> { loadingLayout.setVisibility(View.GONE); showError("Error: " + e.getMessage()); });
            }
        });
    }

    private String callClaudeAPIWithHistory(List<JSONObject> history) throws Exception {
        JSONObject requestBody = new JSONObject();
        requestBody.put("model", MODEL);
        requestBody.put("max_tokens", 2000);
        requestBody.put("system", "You are a WhatsApp reply assistant. Always respond ONLY with valid JSON. No preamble, no markdown fences.");

        JSONArray messages = new JSONArray();
        for (JSONObject msg : history) messages.put(msg);
        requestBody.put("messages", messages);

        URL url = new URL("https://api.anthropic.com/v1/messages");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", API_KEY);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);

        OutputStream os = conn.getOutputStream();
        os.write(requestBody.toString().getBytes("UTF-8"));
        os.close();

        int responseCode = conn.getResponseCode();
        InputStream is = responseCode == 200 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) response.append(line);
        reader.close();

        if (responseCode != 200) throw new Exception("API error " + responseCode + ": " + response);

        JSONObject resp = new JSONObject(response.toString());
        String text = resp.getJSONArray("content").getJSONObject(0).getString("text");

        // Add this response to history too
        try {
            JSONObject assistantMsg = new JSONObject();
            assistantMsg.put("role", "assistant");
            assistantMsg.put("content", text);
            conversationHistory.add(assistantMsg);
        } catch (Exception ignored) {}

        return text;
    }

    private void showError(String msg) {
        loadingLayout.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        errorText.setText("Error: " + msg);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
