package com.whatsappreply;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button settingsBtn = findViewById(R.id.settingsBtn);
        if (settingsBtn != null) settingsBtn.setOnClickListener(v -> showSettingsDialog());

        TextView statusText = findViewById(R.id.statusText);
        if (statusText != null) {
            String key = getSharedPreferences(ShareReceiverActivity.PREFS_NAME, MODE_PRIVATE)
                    .getString(ShareReceiverActivity.API_KEY_PREF, "");
            if (key.isEmpty()) {
                statusText.setText("Tap Settings to add your Anthropic API key.");
                if (settingsBtn != null) settingsBtn.post(this::showSettingsDialog);
            }
        }
    }

    private void showSettingsDialog() {
        SharedPreferences prefs = getSharedPreferences(ShareReceiverActivity.PREFS_NAME, MODE_PRIVATE);
        String existing = prefs.getString(ShareReceiverActivity.API_KEY_PREF, "");

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        input.setHint("sk-ant-api03-...");
        input.setText(existing);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AlertDialog.Builder(this)
                .setTitle("API Key Settings")
                .setMessage("Paste your Anthropic API key. It's stored only on this device and sent directly to Anthropic when generating replies.\n\nGet a key at console.anthropic.com.")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String key = input.getText().toString().trim();
                    if (!key.isEmpty() && !key.startsWith("sk-ant-")) {
                        Toast.makeText(this, "Key should start with sk-ant-", Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs.edit().putString(ShareReceiverActivity.API_KEY_PREF, key).apply();
                    TextView statusText = findViewById(R.id.statusText);
                    if (statusText != null) {
                        statusText.setText(key.isEmpty()
                                ? "Tap Settings to add your Anthropic API key."
                                : "Waiting for a shared chat...");
                    }
                    Toast.makeText(this, key.isEmpty() ? "API key cleared" : "API key saved", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Clear", (d, w) -> {
                    prefs.edit().remove(ShareReceiverActivity.API_KEY_PREF).apply();
                    TextView statusText = findViewById(R.id.statusText);
                    if (statusText != null) statusText.setText("Tap Settings to add your Anthropic API key.");
                    Toast.makeText(this, "API key cleared", Toast.LENGTH_SHORT).show();
                })
                .show();
    }
}
